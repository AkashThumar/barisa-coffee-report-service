package com.barista.coffee.orderservice.bean;

public enum OrderStatusEnum {

	PLACED, PREPARING, READY, COMPLETED
	
}
