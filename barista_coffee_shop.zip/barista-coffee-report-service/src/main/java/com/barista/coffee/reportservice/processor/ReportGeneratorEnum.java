package com.barista.coffee.reportservice.processor;

public enum ReportGeneratorEnum {

	Default, MostSold
}
