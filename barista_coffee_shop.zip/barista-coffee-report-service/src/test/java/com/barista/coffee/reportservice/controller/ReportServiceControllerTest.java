package com.barista.coffee.reportservice.controller;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ReportServiceControllerTest {
}
