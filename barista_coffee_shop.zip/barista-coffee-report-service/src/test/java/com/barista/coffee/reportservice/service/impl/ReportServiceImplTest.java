package com.barista.coffee.reportservice.service.impl;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ReportServiceImplTest {

}
